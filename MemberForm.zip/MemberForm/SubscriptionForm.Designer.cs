﻿namespace MemberForm
{
    partial class SubscriptionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtSub = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtStartDate = new TextBox();
            txtEndDate = new TextBox();
            label6 = new Label();
            chkIsInStreak = new CheckBox();
            btnSave = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(54, 65);
            label1.Name = "label1";
            label1.Size = new Size(94, 15);
            label1.TabIndex = 0;
            label1.Text = "Subscription for:";
            // 
            // txtSub
            // 
            txtSub.Location = new Point(153, 62);
            txtSub.Name = "txtSub";
            txtSub.Size = new Size(100, 23);
            txtSub.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(54, 184);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 2;
            label2.Text = "Start Date";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(54, 248);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 3;
            label3.Text = "End Date";
            label3.Click += label3_Click;
            // 
            // txtStartDate
            // 
            txtStartDate.Location = new Point(153, 184);
            txtStartDate.Name = "txtStartDate";
            txtStartDate.Size = new Size(100, 23);
            txtStartDate.TabIndex = 4;
            // 
            // txtEndDate
            // 
            txtEndDate.Location = new Point(153, 240);
            txtEndDate.Name = "txtEndDate";
            txtEndDate.Size = new Size(100, 23);
            txtEndDate.TabIndex = 5;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(54, 377);
            label6.Name = "label6";
            label6.Size = new Size(63, 15);
            label6.TabIndex = 8;
            label6.Text = "Is in Streak";
            // 
            // chkIsInStreak
            // 
            chkIsInStreak.AutoSize = true;
            chkIsInStreak.Location = new Point(162, 377);
            chkIsInStreak.Name = "chkIsInStreak";
            chkIsInStreak.Size = new Size(15, 14);
            chkIsInStreak.TabIndex = 12;
            chkIsInStreak.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(54, 514);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 13;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            // 
            // SubscriptionForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1523, 733);
            Controls.Add(btnSave);
            Controls.Add(chkIsInStreak);
            Controls.Add(label6);
            Controls.Add(txtEndDate);
            Controls.Add(txtStartDate);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtSub);
            Controls.Add(label1);
            Name = "SubscriptionForm";
            Text = "SubscriptionForm";
            Load += SubscriptionForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtSub;
        private Label label2;
        private Label label3;
        private TextBox txtStartDate;
        private TextBox txtEndDate;
        private Label label6;
        private CheckBox chkIsInStreak;
        private Button btnSave;
    }
}