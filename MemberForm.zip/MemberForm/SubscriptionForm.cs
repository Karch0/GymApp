﻿using ConsoleApp4.Models.Data;
using System;
using System.Windows.Forms;

namespace MemberForm
{
    public partial class SubscriptionForm : Form
    {
        public Subscription Subscription { get; private set; }

        public SubscriptionForm()
        {
            InitializeComponent();
            this.Load += SubscriptionForm_Load;
        }

        public SubscriptionForm(Subscription subscription) : this()
        {
            Subscription = subscription;
        }

        private void SubscriptionForm_Load(object sender, EventArgs e)
        {
            LoadSubscriptionData();
        }

        private void LoadSubscriptionData()
        {
            if (Subscription != null)
            {
                txtStartDate.Text = Subscription.StartDate.ToString("yyyy-MM-dd");
                txtEndDate.Text = Subscription.EndDate.ToString("yyyy-MM-dd");
                chkIsInStreak.Checked = Subscription.IsInStreak;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (Subscription == null)
            {
                Subscription = new Subscription();
            }

            if (DateTime.TryParse(txtStartDate.Text, out DateTime startDate))
            {
                Subscription.StartDate = startDate;
            }
            else
            {
                MessageBox.Show("Invalid Start Date format. Please use YYYY-MM-DD.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (DateTime.TryParse(txtEndDate.Text, out DateTime endDate))
            {
                Subscription.EndDate = endDate;
            }
            else
            {
                MessageBox.Show("Invalid End Date format. Please use YYYY-MM-DD.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Subscription.IsInStreak = chkIsInStreak.Checked;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }
    }
}
