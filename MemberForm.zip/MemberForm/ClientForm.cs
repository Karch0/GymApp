using ConsoleApp4.Models.Data;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MemberForm
{
    public partial class ClientForm : Form
    {
        private List<Client> clients = new List<Client>();

        public ClientForm()
        {
            InitializeComponent();

            this.Load += ClientForm_Load;
            btnRegister.Click += BtnAddClient_Click;
            btnEdit.Click += BtnEditSubscription_Click;
        }

        private void ClientForm_Load(object sender, EventArgs e)
        {
            UpdateGrid();
            ClearTextBoxes();
        }

        private void BtnAddClient_Click(object sender, EventArgs e)
        {
            var name = txtName.Text.Trim();
            var email = txtEmail.Text.Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Please enter both Name and Email.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (clients.Exists(c => c.Email.Equals(email, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("A client with this email already exists.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Client client = new Client
            {
                FullName = name,
                Email = email,
                Subscription = null
            };

            clients.Add(client);
            UpdateGrid();
            ClearTextBoxes();
        }

        private void BtnEditSubscription_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a client first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var selectedEmail = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

            Client selectedClient = clients.Find(c => c.Email.Equals(selectedEmail, StringComparison.OrdinalIgnoreCase));

            if (selectedClient == null)
            {
                MessageBox.Show("Client not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (selectedClient.Subscription == null)
            {
                selectedClient.Subscription = new Subscription();
            }

            using (SubscriptionForm subscriptionForm = new SubscriptionForm(selectedClient.Subscription))
            {
                if (subscriptionForm.ShowDialog() == DialogResult.OK)
                {
                    
                    UpdateGrid();
                }
            }
        }

        private void UpdateGrid()
        {
            var displayClients = clients.ConvertAll(c => new
            {
                FullName = c.FullName,
                Email = c.Email,
                HasSubscription = c.Subscription != null ? "Yes" : "No"
            });

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = displayClients;
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearTextBoxes()
        {
            txtName.Text = "";
            txtEmail.Text = "";
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
    }
}
